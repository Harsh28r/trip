All Function & codes are written in Control Folder
