<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="UTF-8">
    <title>Login -Trip24</title>
    <meta name="keywords" content="HTML5 Admin Template" />
    <meta name="description" content="Login -Trip24">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css">
    <!-- Page CSS -->
    <link rel="stylesheet" href="assets/css/custompages/login1.css">
    <!-- Fonts CSS -->
    <link rel="stylesheet" href="assets/css/fonts/fonts-style.css">
</head>

<body class="bg-login">
    <div class="wrapper">
        <!-- Page Content Starts-->
        <div class="content-wrapper">
            <div class="mx-auto login">
                <!-- <a href="index"><img src="assets/images/logo-signin.png" class="img-circle" alt="Logo Image"></a> -->
                <div class="card card-signin mt-4">
                    <div class="card-body">
                        <h5 class="card-title text-center">Sign In</h5>
                        <form class="form-signin">
                            <div class="form-label-group">
                                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
                            </div>
                            <div class="form-label-group">
                                <input type="password" id="inputPassword" class="form-control" placeholder="Password" required>
                            </div>
                            <div class="row remember">
                                <div class="col-md-7 text-center text-md-left">
                                    <div class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input" id="customCheck1">
                                        <label class="custom-control-label" for="customCheck1">Remember password</label>
                                    </div>
                                </div>
                                <div class="col-md-5 text-center text-md-right mb-3">
                                    <a href="forgot-password" class="">Forgot Password?</a>
                                </div>
                            </div>
                            <a href="index" class="btn btn-lg btn-primary btn-block text-uppercase text-center">Sign in</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Content Ends-->
    </div>

    <!-- Bootstrap JS -->
    <script src="assets/js/jquery/jquery.min.js"></script>
    <script src="assets/js/bootstrap/bootstrap.min.js"></script>
</body>



</html>